create definer = root@localhost view view_person as
select `pay`.`person`.`No`        AS `no`,
       `pay`.`person`.`Name`      AS `Name`,
       `pay`.`person`.`Sex`       AS `Sex`,
       `pay`.`person`.`Professor` AS `Professor`,
       `pay`.`person`.`DeptNo`    AS `DeptNo`
from `pay`.`person`;

