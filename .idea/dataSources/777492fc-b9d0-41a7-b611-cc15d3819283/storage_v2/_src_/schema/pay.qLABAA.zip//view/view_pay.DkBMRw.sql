create definer = root@localhost view view_pay as
select `pay`.`pay`.`Year`         AS `Year`,
       `pay`.`pay`.`Month`        AS `Month`,
       `pay`.`person`.`No`        AS `No`,
       `pay`.`person`.`Name`      AS `Name`,
       `pay`.`person`.`Sex`       AS `Sex`,
       `pay`.`person`.`Professor` AS `Professor`,
       `pay`.`dept`.`DeptName`    AS `DeptName`,
       `pay`.`pay`.`Base`         AS `Base`,
       `pay`.`pay`.`Bouns`        AS `Bouns`,
       `pay`.`pay`.`Deduct`       AS `Deduct`,
       `pay`.`pay`.`Fact`         AS `Fact`
from `pay`.`dept`
         join `pay`.`person`
         join `pay`.`pay`
where ((`pay`.`dept`.`DeptNo` = `pay`.`person`.`DeptNo`) and (`pay`.`person`.`No` = `pay`.`pay`.`No`));

